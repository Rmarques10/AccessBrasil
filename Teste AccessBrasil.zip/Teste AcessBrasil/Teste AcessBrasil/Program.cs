﻿using System.Globalization;

int n = 0;
double eficiencia, media, soma = 0, n1 = 0.0, qtd = 0.0;


Console.WriteLine("Informe a quantidade de amostras :");
n = int.Parse(Console.ReadLine());

double[] amostra = new double[n];

for (int i = 0; i < n; i++)
{
    Console.WriteLine("Informe o valor da " + (i+1) + "° amostra");
    amostra[i] = double.Parse(Console.ReadLine());
    
    soma += amostra[i];
    n1++;
}

media = soma / n1;

for(int i = 0; i < n; i++)
{
    if(amostra[i] > media)
    {
        qtd++;
    }
}

eficiencia = 100 / n1 * qtd;

Console.WriteLine("Média: " + media);
Console.WriteLine("Eficiência / Alunos acima da média :" + eficiencia.ToString("F3", CultureInfo.InvariantCulture) + "%");